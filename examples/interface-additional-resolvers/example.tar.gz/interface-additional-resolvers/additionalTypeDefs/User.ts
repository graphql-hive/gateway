export const extraDefs = /* GraphQL */ `
  extend type User implements Node {
    self: Node!
  }
`;
